<?php

$flag = "ITAC{Wrong_IP_Detection_may_leads_to_security_issue}";