<?php

$flag = "ITAC{1_d0n7_th1nk_4ny1_c4n_s0lv3_th1s_lol}";
